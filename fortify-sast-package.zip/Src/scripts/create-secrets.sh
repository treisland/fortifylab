#!/bin/bash
#
# CREATE SECRETS
# -----------------------------------
#
# Single entry point that builds every k8s Secret the Fortify charts need.
#
# Inputs:
#   secrets/input/       — user-provided files (license, etc.)
#   secrets/templates/   — committed templates rendered with envsubst
#   secrets/generated/   — wiped and rebuilt each run
#   .env                 — domain, credentials, image versions
#
# See secrets/README.md for the full file → secret → consumer map.
#========================================================

set -euo pipefail

if [ -z "${FORTIFY_HOME_K8S:-}" ]; then
    FORTIFY_HOME_K8S="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    export FORTIFY_HOME_K8S
fi

source "$FORTIFY_HOME_K8S/.env"
source "$FORTIFY_HOME_K8S/scripts/lib/fortify-license.sh"
source "$FORTIFY_HOME_K8S/scripts/lib/registry-credentials.sh"

# Running under sudo would create files in secrets/generated/ owned by root,
# which then block subsequent normal-user runs from rebuilding the directory.
# microk8s group membership covers cluster ops without sudo; if you don't
# have it yet, run: sudo usermod -aG microk8s "$USER" && newgrp microk8s
if [ "$(id -u)" -eq 0 ] || [ -n "${SUDO_USER:-}" ]; then
  echo "❌ Do not run create-secrets.sh as root or via sudo."
  echo "   It writes to secrets/generated/; root ownership there will break"
  echo "   future runs by your normal user. Add yourself to the microk8s"
  echo "   group instead: sudo usermod -aG microk8s \"\$USER\" && newgrp microk8s"
  exit 1
fi

INPUT_DIR="$FORTIFY_HOME_K8S/secrets/input"
TEMPLATES_DIR="$FORTIFY_HOME_K8S/secrets/templates"
GENERATED_DIR="$FORTIFY_SECRETS_GENERATED"
SSC_GEN_DIR="$GENERATED_DIR/ssc"
PRESERVED_SECRET_KEY="$(mktemp)"
trap 'rm -f "$PRESERVED_SECRET_KEY"' EXIT

KUBECTL="microk8s kubectl"

configure_microk8s_ingress_default_tls() {
  local cert_ref="$NAMESPACE/tls"

  # MicroK8s 1.35+ backs the ingress addon with Traefik. Some migrated
  # clusters route Ingress TLS but still serve Traefik's generated default
  # certificate unless the addon has an explicit default certificate. Keep this
  # best-effort so older MicroK8s tracks do not block secret creation.
  if microk8s enable ingress --help 2>&1 | grep -q -- '--default-ssl-certificate'; then
    if microk8s enable ingress --default-ssl-certificate "$cert_ref" >/dev/null 2>&1; then
      echo "✅ MicroK8s ingress default TLS certificate set to $cert_ref"
    else
      echo "⚠️ Could not update MicroK8s ingress default TLS certificate to $cert_ref."
      echo "   If Traefik still serves TRAEFIK DEFAULT CERT, run:"
      echo "   microk8s enable ingress --default-ssl-certificate $cert_ref"
    fi
  fi
}


#--------------------------
# SECTION: PRE-FLIGHT CHECKS
#--------------------------

fortify_resolve_license_file || exit 1

if [ ! -f "$TRUSTSTORE" ] || [ ! -f "$JVM_KEYSTORE" ]; then
  echo "❌ Certs/keystores not found. Run scripts/create-certs.sh first."
  exit 1
fi


#--------------------------
# SECTION: NAMESPACE
#--------------------------

$KUBECTL get namespace "$NAMESPACE" &>/dev/null \
  || $KUBECTL create namespace "$NAMESPACE"


#--------------------------
# SECTION: REBUILD GENERATED/
#--------------------------
# Wipe everything under generated/ so stale files (old backups, removed
# license files, etc.) never leak into a Secret. Cert artifacts live in
# $FORTIFY_CERTS, not here, so this is safe.

# Preserve the live SSC encryption key before rebuilding local artifacts. An
# existing SSC database cannot decrypt stored credentials with a replacement.
$KUBECTL -n "$NAMESPACE" get secret fortify-secrets \
  -o jsonpath='{.data.secret\.key}' 2>/dev/null \
  | base64 -d > "$PRESERVED_SECRET_KEY" 2>/dev/null || true

rm -rf "$GENERATED_DIR"
mkdir -p "$SSC_GEN_DIR"

# Render ssc.autoconfig from template using DB credentials from .env.
# Uses ${VAR} substitution only — leaves $-prefixed db.username untouched.
SSC_DB_USER="${SSC_DB_USER:-root}"
SSC_DB_PASSWORD="${SSC_DB_PASSWORD:-$DEFAULT_PASS}"
export SSC_DB_USER SSC_DB_PASSWORD
envsubst '${SSC_DB_USER} ${SSC_DB_PASSWORD}' \
  < "$TEMPLATES_DIR/ssc.autoconfig.template" \
  > "$SSC_GEN_DIR/ssc.autoconfig"

# SSC's secret.key is NOT plain random bytes — it's a structured Fortify
# keystore with a specific binary header. `openssl rand` output is rejected
# by SSC's pwtool with "Unable to read secret key from Fortify key store".
#
# We use a committed sample key from templates/ for new deploys (fine for
# a lab/demo — every clone gets the same key). For production, generate
# a fresh one with Fortify's pwtool inside the SSC container and replace
# this file.
#
# Once an SSC instance has stored encrypted credentials in its DB with
# a given key, that key MUST stay constant. We therefore reuse the
# existing $SSC_GEN_DIR/secret.key if it's already present (e.g. on a
# re-run of create-secrets.sh against a live cluster) instead of
# rotating it.
if [ -s "$PRESERVED_SECRET_KEY" ]; then
    cp "$PRESERVED_SECRET_KEY" "$SSC_GEN_DIR/secret.key"
elif [ -s "$TEMPLATES_DIR/secret.key.sample" ]; then
    cp "$TEMPLATES_DIR/secret.key.sample" "$SSC_GEN_DIR/secret.key"
else
    echo "❌ No secret.key.sample found in templates/ and no existing key in generated/."
    echo "   For a fresh install you can copy a sample key from a Fortify SSC pod:"
    echo "     kubectl -n $NAMESPACE exec ssc-webapp-0 -- /app/tools/...  # see SSC docs"
    exit 1
fi


#--------------------------
# SECTION: DELETE EXISTING SECRETS
#--------------------------

$KUBECTL -n "$NAMESPACE" delete secret --ignore-not-found \
  regcred \
  fortify-secrets \
  tls \
  tls-pfx \
  tls-pfx-password \
  scdast-utilityservice-certificate \
  scdast-db-owner \
  scdast-db-standard \
  scdast-ssc-serviceaccount \
  scdast-service-token \
  lim-pool \
  lim-admin-credentials \
  lim-jwt-security-key \
  lim-server-certificate \
  lim-signing-certificate \
  lim-signing-certificate-password


#--------------------------
# SECTION: CREATE SECRETS
#--------------------------

# fortify-secrets: a single Secret that SSC AND ScanCentral SAST both pull
# from (chart contract — see apps/ssc/start.sh secretRef.keys.* and the SAST
# chart's valueFrom.secretKeyRef references). Keys are added explicitly by
# name — never --from-file <dir> — to keep stray files (READMEs, backups,
# public CAs) from leaking in.
#
# The scancentral-* tokens are required by the SAST chart even though our
# scripts don't read them directly: the controller and workers pull them
# via secretKeyRef. Generated fresh per install so two clones of this repo
# don't share authentication tokens.
$KUBECTL -n "$NAMESPACE" create secret generic fortify-secrets \
  --from-file=fortify.license="$FORTIFY_LICENSE_FILE" \
  --from-file=ssc.autoconfig="$SSC_GEN_DIR/ssc.autoconfig" \
  --from-file=secret.key="$SSC_GEN_DIR/secret.key" \
  --from-file=keystore.jks="$JVM_KEYSTORE" \
  --from-file=truststore="$TRUSTSTORE" \
  --from-literal=default_password="$DEFAULT_PASS" \
  --from-literal=scancentral-client-auth-token="$(openssl rand -base64 32 | tr -d '[:punct:]\n' | head -c 48)" \
  --from-literal=scancentral-worker-auth-token="$(openssl rand -base64 32 | tr -d '[:punct:]\n' | head -c 48)" \
  --from-literal=scancentral-ssc-scancentral-ctrl-secret="$(openssl rand -base64 32 | tr -d '[:punct:]\n' | head -c 48)" \
  --from-file=jvm_truststore="$TRUSTSTORE" \
  --from-file=http_truststore="$TRUSTSTORE" \
  --from-literal=keystore_password="$DEFAULT_PASS" \
  --from-literal=key_password="$DEFAULT_PASS" \
  --from-literal=jvm_truststore_password="$DEFAULT_PASS" \
  --from-literal=http_truststore_password="$DEFAULT_PASS" \
  --from-literal=keystore_alias="$DEFAULT_ALIAS"
# keystore_alias is the JKS alias baked into keystore.jks/keystore.p12 by
# create-certs.sh — required by the 26.2+ ScanCentral SAST controller chart's
# controller.serverCertificateKeyAliasKey (see apps/scsast/start.sh).
# keystore_password/key_password/jvm_truststore_password/http_truststore_password
# and jvm_truststore/http_truststore duplicate default_password/truststore under
# distinct key names. The 26.2+ SSC chart derives each container volumeMount's
# path from the discrete secret Key name (not a fixed per-field path), so two
# fields sharing one key name (e.g. both truststore password fields using
# "default_password") collide on mountPath and kubectl's strategic-merge-patch
# rejects the StatefulSet update ("doesn't match $setElementOrder list"). See
# apps/ssc/start.sh, which maps each field to one of these unique keys.

# Ingress server cert (kubernetes.io/tls type — required by ingress controllers).
$KUBECTL -n "$NAMESPACE" create secret tls tls \
  --cert="$SERVER_CERT" --key="$SERVER_KEY"
configure_microk8s_ingress_default_tls

# LIM signing cert (PFX) + password.
$KUBECTL -n "$NAMESPACE" create secret generic tls-pfx \
  --type=Opaque --from-file=tls.pfx="$ROOTCA_PFX"
$KUBECTL -n "$NAMESPACE" create secret generic tls-pfx-password \
  --type=Opaque --from-literal=password="$DEFAULT_PASS"

# ScanCentral DAST utilityservice's own TLS server cert. Must be a real leaf
# (tls-pfx above is the CA root, used for LIM signing — presenting a CA cert
# as a server cert makes clients see a self-signed-certificate warning).
# Reuses the same leaf/password as keystore.jks (tls-pfx-password).
$KUBECTL -n "$NAMESPACE" create secret generic scdast-utilityservice-certificate \
  --type=Opaque --from-file=tls.pfx="$KEYSTORE"

# SCDAST DB users.
$KUBECTL -n "$NAMESPACE" create secret generic scdast-db-owner \
  --type=basic-auth \
  --from-literal=username="$SCDAST_DB_OWNER_USER" \
  --from-literal=password="$SCDAST_DB_OWNER_PASS"
$KUBECTL -n "$NAMESPACE" create secret generic scdast-db-standard \
  --type=basic-auth \
  --from-literal=username="$SCDAST_DB_STANDARD_USER" \
  --from-literal=password="$SCDAST_DB_STANDARD_PASS"

# SCDAST → SSC service account.
$KUBECTL -n "$NAMESPACE" create secret generic scdast-ssc-serviceaccount \
  --type=basic-auth \
  --from-literal=username="$SCDAST_SSC_USER" \
  --from-literal=password="$SCDAST_SSC_PASS"

# SCDAST core ↔ scanner shared secret (generated fresh).
$KUBECTL -n "$NAMESPACE" create secret generic scdast-service-token \
  --type=Opaque \
  --from-literal=service-token="$(openssl rand -base64 32)"

# LIM secrets.
$KUBECTL -n "$NAMESPACE" create secret generic lim-pool \
  --type=basic-auth \
  --from-literal=username="$LIM_POOL_NAME" \
  --from-literal=password="$LIM_POOL_PASS"
$KUBECTL -n "$NAMESPACE" create secret generic lim-admin-credentials \
  --type=basic-auth \
  --from-literal=username=lim_admin \
  --from-literal=password="$LIM_SIGNING_CERT_PWD"
$KUBECTL -n "$NAMESPACE" create secret generic lim-jwt-security-key \
  --type=Opaque \
  --from-literal=token="$(openssl rand -base64 32 | tr -d '[:punct:]')"
$KUBECTL -n "$NAMESPACE" create secret tls lim-server-certificate \
  --cert="$LIM_SERVER_CERT_PEM" --key="$LIM_SERVER_KEY_PEM"
$KUBECTL -n "$NAMESPACE" create secret generic lim-signing-certificate \
  --type=Opaque --from-file=tls.pfx="$LIM_SIGNING_CERT_PFX"
$KUBECTL -n "$NAMESPACE" create secret generic lim-signing-certificate-password \
  --type=Opaque --from-literal=pfx.password="$LIM_SIGNING_CERT_PWD"


#--------------------------
# SECTION: REGCRED (Docker Hub pull credentials)
#--------------------------
# Materialize Docker Hub credentials into a Kubernetes-readable pull Secret.
# Docker itself can use local credential helpers; kubelet cannot.
refresh_registry_credentials
echo
echo "✅ Secrets created in namespace '$NAMESPACE'."
